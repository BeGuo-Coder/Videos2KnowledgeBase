---
name: flowgate-video-parser
description: parse and transcribe a social video/image-note link into a Markdown report via the hosted FlowGate API (kb.apimar.online). use when the user provides a douyin, bilibili, xiaohongshu, tiktok, youtube, kuaishou, weibo or similar link and asks to parse, transcribe, summarize, extract content or produce a content report, AND wants to use the hosted pay-per-use API (only a FlowGate API Key required, no local DashScope/parser setup). also supports checking credit balance, usage history and redeeming top-up codes. this is the thin-client counterpart to the local social-video-transcriber skill.
---

# FlowGate Video Parser (hosted API client)

## Overview

This skill turns one social-video/image-note URL into a Markdown content report by calling the
**hosted FlowGate API** (`https://kb.apimar.online` by default). The API does all the heavy lifting
server-side — media parsing, `gpt-4o-transcribe` speech-to-text, text correction, and multimodal
image OCR — and bills per success in credits. The user only needs a **FlowGate API Key**.

Use this skill when the user wants the managed API. If instead they want to run everything locally
with their own DashScope key and self-hosted parser, use the sibling `social-video-transcriber` skill.
It handles both a **single link** and a **batch spreadsheet** (Excel/CSV → packaged knowledge base).

Respect platform terms, copyright, and authorization. Only process public content; do not help
bypass paywalls, login walls, or access controls.

## Required configuration

Put a `.env.local` next to this `SKILL.md` (the bundled script auto-loads `.env` / `.env.local`
without overwriting existing environment variables):

```bash
FLOWGATE_API_KEY="your_flowgate_api_key"      # required
FLOWGATE_BASE_URL="https://kb.apimar.online"  # optional, this is the default
FLOWGATE_OUTPUT_DIR="./reports"               # optional, where to save .md reports
```

Get an API Key by registering at `https://kb.apimar.online/login`. Never print the API Key.

## Standard workflow

### 1. Parse + transcribe a link

Run the bundled client (pure Python standard library, no `pip` install needed):

```bash
python scripts/flowgate.py transcribe "https://v.douyin.com/xxxxx/" --output report.md
```

Options:
- `--no-transcribe` — only fetch metadata + media URL, skip speech-to-text (cheaper).
- `--output report.md` — save the Markdown report to a file (otherwise printed to stdout).
- `--json` — print the full JSON response instead of the human-readable report.

### Transcribe a **local** audio/video file (upload)

When the user has a file on disk (not a URL) — a recording, a downloaded clip, a
podcast — upload it directly; the server extracts audio with ffmpeg and, for
long media, splits it into chunks and merges the transcript:

```bash
python scripts/flowgate.py transcribe-file "C:/path/to/lecture.mp4" --output report.md
python scripts/flowgate.py transcribe-file ./audio.m4a --no-transcribe   # register only
```

Accepts common audio (mp3/m4a/aac/wav/ogg/opus/flac) and video (mp4/mov/mkv/webm/
avi/flv/…) formats. Large videos are fine — the server strips the video track
and transcribes the audio; anything over the ASR size limit is auto-chunked and
recombined. Output, billing and error handling match `transcribe` above. (Raw
upload size is capped by the server's `MAX_UPLOAD_MB`; oversized files return HTTP 413.)

The script prints a basic-info summary, the `report_markdown` returned by the API (基本信息表 +
正文 + 关键词标签), and a billing line: **本次扣费 N 积分 · 剩余余额 M**. Present the report to the
user as-is; you may add a short summary or extract keywords, but do not invent missing fields.

### 2. Handle the common outcomes

- **Success** — show the report and the credits charged + remaining balance.
- **余额不足 (HTTP 402)** — the script explains the balance and required credits. Tell the user to
  top up with `redeem <卡密>`, then retry.
- **解析失败 (HTTP 502)** — the script prints the failing `stage` (parse/download/transcribe/vision)
  and message. **The user is not billed for failures.** Suggest retrying or a different link.
- **API Key 无效 (HTTP 401)** — ask the user to check `FLOWGATE_API_KEY`.

### 3. Account helpers

```bash
python scripts/flowgate.py balance            # 查询积分余额（含邀请码/返积分）
python scripts/flowgate.py usage --limit 20   # 最近用量流水
python scripts/flowgate.py redeem <卡密>       # 兑换卡密充值
```

### 4. Batch parse a spreadsheet → knowledge base

When the user has an Excel/CSV export of many works (a `作品链接` / `笔记链接` / `链接` column),
parse them all in one job and get a packaged Obsidian-style knowledge base zip:

```bash
python scripts/flowgate.py batch works.xlsx                 # submit, wait, download zip
python scripts/flowgate.py batch works.xlsx --no-wait       # just submit, poll later
python scripts/flowgate.py batch-list                       # my batch jobs
python scripts/flowgate.py batch-status BAT2026... --download  # check + fetch the zip
```

The server parses each row on a worker pool, **bills per successful row** (failed rows are free),
auto-retries failures once, and packages a zip of per-note Markdown + an index `.md` + a summary
`.xlsx`. The client prints live progress (`处理 / 成功 / 失败 / 计费`) and saves
`knowledge_base_<batch_no>.zip` (honoring `FLOWGATE_OUTPUT_DIR` / `--output`). Single job is capped
server-side (`BATCH_MAX_ROWS`); if the file exceeds it, split it and submit in parts.

## Output format

The API already returns a report shaped like:

```markdown
# 视频内容解析报告

## 基本信息
| 字段 | 内容 |
|---|---|
| 平台 |  |
| 标题 |  |
| 作者 |  |
| 发布时间 |  |
| 原始链接 |  |

## 内容
[转写正文]

## 关键词 / 标签
- ...
```

Prefer this returned `report_markdown` verbatim. Keep it factual; use `未知` for missing metadata.

## Billing (credits)

Every successful parse costs a base credit (保底) plus a token surcharge for transcription /
correction / image recognition, rounded up. **Failed parses are not billed.** Always surface the
`billing.total_credits` and remaining `balance` so the user sees the cost. See `references/api.md`
for the full pricing and field reference.

## Bundled resources

- `scripts/flowgate.py` — CLI client for the FlowGate API (`transcribe` / `transcribe-file` / `batch` / `batch-list` / `batch-status` / `balance` / `usage` / `redeem`).
- `references/api.md` — endpoint, request/response fields, error codes, and pricing reference.
