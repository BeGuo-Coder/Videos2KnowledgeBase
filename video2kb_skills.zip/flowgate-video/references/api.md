# FlowGate API 速查

托管服务，默认 `https://kb.apimar.online`。除 `/health`、`/pricing` 外均需鉴权：

```
Authorization: Bearer <FLOWGATE_API_KEY>
```

## POST /v1/transcribe

解析并（可选）转写一个链接。

请求体：

```json
{ "url": "https://v.douyin.com/xxxxx/", "transcribe": true }
```

- `url`（必填）：公开的社交视频/图文链接。
- `transcribe`（可选，默认 `true`）：`false` 时只取元信息与媒体地址，跳过语音转写。

成功 `200` 响应（关键字段）：

| 字段 | 说明 |
|---|---|
| `platform` / `title` / `author` / `publish_time` | 基本元信息 |
| `media_url` / `video_url` / `audio_url` / `cover_url` | 媒体与封面地址 |
| `images` / `image_count` | 图文笔记的图片列表 |
| `content_type` | `video` 或 `image_note` |
| `transcript` | 转写正文（图文笔记则为视觉识别文本） |
| `corrected` | 是否经过文本纠错 |
| `report_markdown` | 直接可用的 Markdown 报告（**首选输出**） |
| `notes` | 处理备注（如转写为空、图文识别张数等） |
| `billing` | `{ base_credits, transcribe_tokens, correction_tokens, vision_tokens, token_credits, total_credits }` |
| `balance` | 扣费后的剩余积分 |
| `duration_ms` | 本次处理耗时 |

## POST /v1/transcribe-file

上传**本地音视频文件**转写（`multipart/form-data`）。服务端用 ffmpeg 抽音频、超过单次上限自动**分片转写再合并**。

- `file`（必填）：本地音频/视频文件。支持 mp3/m4a/aac/wav/ogg/opus/flac + mp4/mov/mkv/webm/avi/flv/... 等常见格式。
- `transcribe`（可选表单字段，默认 `true`）：`false` 时只登记文件信息、跳过转写。
- 原始文件大小上限由服务端 `MAX_UPLOAD_MB`（默认 200MB）控制；反向代理（nginx）也需放宽 `client_max_body_size`。超限返回 `413`。

成功 `200` 响应字段与 `/v1/transcribe` 相同（`content_type` 为 `audio`/`video`，无 `media_url`/`images`）。计费口径一致：保底 + 各分片 transcribe token 累加 + 一次纠错 token，**失败不计费**。

## GET /v1/balance

`{ balance, name, username, invite_code, invite_count, invite_reward_total }`

## GET /v1/usage?limit=N

`{ usage: [ { created_at, status, platform, content_type, credits_charged, url, ... } ] }`（最多 200 条）

## POST /v1/redeem

请求体 `{ "code": "<卡密>" }`。成功：`{ success, credits_added, balance, message }`。

## 批量解析（Excel/CSV → 知识库 zip）

- **POST `/v1/batch`** — `multipart/form-data`，字段 `file` 为 `.xlsx` / `.xls` / `.csv`，需含「作品链接」列
  （表头可为 `作品链接` / `笔记链接` / `视频链接` / `链接` / `url` / `作品url` 之一）。
  成功 `201`：`{ batch_no, total, status: "queued" }`。单次最多 `BATCH_MAX_ROWS` 行。
- **GET `/v1/batch`** — 我的任务列表：`{ batches: [ { batch_no, filename, status, total, processed, succeeded, failed, created_at } ] }`。
- **GET `/v1/batch/<batch_no>`** — 任务进度：`{ batch_no, filename, status, total, processed, succeeded, failed, credits_charged, error }`。
  终态为 `done`（zip 就绪）或 `failed`。
- **GET `/v1/batch/<batch_no>/download`** — 下载打包好的知识库 `zip`（每条笔记 Markdown + 索引 `.md` + 汇总 `.xlsx`）。
  可用 `Authorization: Bearer` 或 `?api_key=` 鉴权；未完成返回 `409`，文件过期返回 `410`。
- 其它：`POST /v1/batch/<no>/retry`（重试某行，body `{ idx }`）、`/delete`、`/restore`、`/purge`。

计费：批量按**每行成功**分别计费（口径同单条），失败行不计费。

## 公开端点

- `GET /health` — `{ status, transcribe_model, correction_model, vision_model, parser_configured }`
- `GET /pricing` — 当前积分费率。

## 错误码

| HTTP | 含义 | 处理 |
|---|---|---|
| `400` | 缺少 `url` / `code` | 补齐参数 |
| `401` | API Key 无效或缺失 | 检查 `FLOWGATE_API_KEY` |
| `402` | 积分余额不足 | 返回 `balance` / `required`，先 `redeem` 充值再重试 |
| `413` | 上传文件超过 `MAX_UPLOAD_MB` | 压缩/本地抽音频后再传，或让服务端调大上限 |
| `502` | 解析/下载/转写失败 | 返回失败 `stage`；**本次不扣费**，可重试或换链接 |

## 计费口径

每次成功解析先收 `base_credits`（保底），再按 transcribe / correction / vision 的 token 消耗
向上取整叠加为 `total_credits`。**解析失败不计费。** 客户端每次都会显示本次扣费与剩余余额。
