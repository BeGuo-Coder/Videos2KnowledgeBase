#!/usr/bin/env python3
"""FlowGate 视频解析 API 客户端。

把一个社交视频/图文链接交给托管的 FlowGate API 解析、转写，并生成 Markdown 报告。
只需一个 API Key（Authorization: Bearer），无需在本地配置 DashScope / 去水印解析接口。

子命令：
  transcribe <url>       解析并转写，输出 Markdown 报告 + 本次计费
  transcribe-file <path> 上传本地音视频文件并转写（大文件自动抽音频+分片）
  batch <file>           批量解析 Excel/CSV（作品链接列）→ 打包知识库 zip
  batch-list             我的批量任务列表
  batch-status <no>      查询某个批量任务进度
  balance                查询积分余额
  usage [--limit N]      最近用量流水
  redeem <code>          兑换卡密充值

配置（环境变量，或与本 skill 同级目录下的 .env / .env.local）：
  FLOWGATE_API_KEY     必填，你的 FlowGate API Key
  FLOWGATE_BASE_URL    可选，默认 https://kb.apimar.online
  FLOWGATE_OUTPUT_DIR  可选，报告默认保存目录

纯 Python 标准库实现，无需 pip 安装任何依赖。
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path

DEFAULT_BASE_URL = "https://kb.apimar.online"


def eprint(*args: object) -> None:
    print(*args, file=sys.stderr)


def load_env_file(path: Path) -> None:
    """加载简单的 KEY=VALUE 行，不覆盖已存在的环境变量。"""
    if not path.exists() or not path.is_file():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


def bootstrap_env() -> None:
    """从 skill 目录读取 .env / .env.local，方便无需全局导出环境变量即可运行。"""
    skill_root = Path(__file__).resolve().parents[1]
    for name in (".env", ".env.local"):
        load_env_file(skill_root / name)


bootstrap_env()


class ApiError(Exception):
    def __init__(self, message: str, status: int | None = None, payload: dict | None = None):
        super().__init__(message)
        self.status = status
        self.payload = payload or {}


def resolve_base_url(args: argparse.Namespace) -> str:
    return (getattr(args, "base_url", "") or os.getenv("FLOWGATE_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")


def resolve_api_key(args: argparse.Namespace) -> str:
    key = (getattr(args, "api_key", "") or os.getenv("FLOWGATE_API_KEY", "")).strip()
    if not key:
        raise ApiError(
            "未设置 API Key。请设置环境变量 FLOWGATE_API_KEY，或在 skill 目录的 .env.local 中填写，"
            f"或用 --api-key 传入。可在 {DEFAULT_BASE_URL}/login 注册获取。"
        )
    return key


def _parse_json(raw: str) -> dict:
    if not raw:
        return {}
    try:
        obj = json.loads(raw)
    except json.JSONDecodeError:
        return {"raw_text": raw[:500]}
    return obj if isinstance(obj, dict) else {"data": obj}


def _error_message(status: int, payload: dict) -> str:
    msg = payload.get("message") or payload.get("error") or payload.get("raw_text") or f"HTTP {status}"
    if status == 401:
        return f"API Key 无效或缺失（请检查 FLOWGATE_API_KEY）。服务返回：{msg}"
    if status == 402:
        balance = payload.get("balance")
        required = payload.get("required")
        extra = f"（当前余额 {balance}，需要 {required}）" if balance is not None else ""
        return f"积分余额不足{extra}。请先用 `redeem <卡密>` 充值后重试。"
    if status == 502:
        stage = payload.get("stage") or "unknown"
        return f"解析失败（阶段：{stage}）：{msg}。本次未扣费，可稍后重试或更换链接。"
    return f"请求失败（HTTP {status}）：{msg}"


def request(method: str, base_url: str, path: str, api_key: str | None,
            body: dict | None = None, timeout: int = 180) -> tuple[int, dict]:
    """发起一次 API 请求，返回 (status, json)。失败抛出 ApiError（不泄露 API Key）。"""
    url = base_url + path
    headers = {"Accept": "application/json"}
    if api_key:
        headers["Authorization"] = "Bearer " + api_key
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", "replace")
            return resp.status, _parse_json(raw)
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", "replace") if exc.fp else ""
        payload = _parse_json(raw)
        raise ApiError(_error_message(exc.code, payload), status=exc.code, payload=payload) from None
    except urllib.error.URLError as exc:
        raise ApiError(f"无法连接 {base_url}：{exc.reason}") from None
    except TimeoutError:
        raise ApiError(f"请求超时（>{timeout}s）。长视频可加大 --timeout 重试。") from None


def _multipart_body(field: str, filename: str, file_bytes: bytes,
                    extra_fields: dict | None = None) -> tuple[str, bytes]:
    """把单个文件（可选附带若干文本字段）编码成 multipart/form-data，返回 (content_type, body)。纯标准库。"""
    boundary = "----flowgate" + uuid.uuid4().hex
    ctype = "application/octet-stream"
    low = filename.lower()
    if low.endswith((".xlsx", ".xls")):
        ctype = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    elif low.endswith(".csv"):
        ctype = "text/csv"
    crlf = b"\r\n"
    parts: list[bytes] = []
    for key, value in (extra_fields or {}).items():
        parts += [
            b"--" + boundary.encode() + crlf,
            (f'Content-Disposition: form-data; name="{key}"').encode("utf-8") + crlf,
            crlf,
            str(value).encode("utf-8"),
            crlf,
        ]
    parts += [
        b"--" + boundary.encode() + crlf,
        (f'Content-Disposition: form-data; name="{field}"; filename="{filename}"').encode("utf-8") + crlf,
        (f"Content-Type: {ctype}").encode() + crlf,
        crlf,
        file_bytes,
        crlf,
        b"--" + boundary.encode() + b"--" + crlf,
    ]
    return "multipart/form-data; boundary=" + boundary, b"".join(parts)


def upload_file(base_url: str, path: str, api_key: str, file_path: Path,
                field: str = "file", timeout: int = 120,
                extra_fields: dict | None = None) -> tuple[int, dict]:
    """上传一个文件（multipart，可附带文本字段），返回 (status, json)。"""
    file_bytes = file_path.read_bytes()
    content_type, body = _multipart_body(field, file_path.name, file_bytes, extra_fields)
    headers = {"Accept": "application/json", "Content-Type": content_type,
               "Authorization": "Bearer " + api_key}
    req = urllib.request.Request(base_url + path, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, _parse_json(resp.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", "replace") if exc.fp else ""
        payload = _parse_json(raw)
        raise ApiError(_error_message(exc.code, payload), status=exc.code, payload=payload) from None
    except urllib.error.URLError as exc:
        raise ApiError(f"无法连接 {base_url}：{exc.reason}") from None


def download_file(base_url: str, path: str, api_key: str, out_path: Path, timeout: int = 300) -> int:
    """下载二进制文件（如知识库 zip）到 out_path，返回写入字节数。"""
    headers = {"Authorization": "Bearer " + api_key}
    req = urllib.request.Request(base_url + path, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = resp.read()
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", "replace") if exc.fp else ""
        raise ApiError(_error_message(exc.code, _parse_json(raw)), status=exc.code) from None
    except urllib.error.URLError as exc:
        raise ApiError(f"无法连接 {base_url}：{exc.reason}") from None
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(data)
    return len(data)


# --------------------------------------------------------------------------- #
# commands
# --------------------------------------------------------------------------- #

def cmd_transcribe(args: argparse.Namespace) -> int:
    base_url = resolve_base_url(args)
    api_key = resolve_api_key(args)
    url = (args.url or "").strip()
    if not url:
        raise ApiError("请提供要解析的公开链接。")

    body = {"url": url, "transcribe": not args.no_transcribe}
    _, data = request("POST", base_url, "/v1/transcribe", api_key, body=body, timeout=args.timeout)

    if args.json:
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0

    _print_summary(data)
    report = data.get("report_markdown") or ""
    out_path = _resolve_output(args, data)
    if out_path:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(report, encoding="utf-8")
        print(f"\n报告已保存：{out_path}")
    elif report:
        print()
        print(report)
    if data.get("notes"):
        print(f"\n备注：{data['notes']}")
    _print_billing(data)
    return 0


def _print_summary(data: dict) -> None:
    rows = [
        ("平台", data.get("platform")),
        ("标题", data.get("title")),
        ("作者", data.get("author")),
        ("发布时间", data.get("publish_time")),
        ("类型", data.get("content_type")),
    ]
    print("=" * 48)
    for label, value in rows:
        if value:
            print(f"{label}：{value}")
    if data.get("content_type") == "image_note" and data.get("image_count"):
        print(f"图片数：{data['image_count']}")
    print("=" * 48)


def _resolve_output(args: argparse.Namespace, data: dict) -> Path | None:
    if args.output:
        return Path(args.output)
    out_dir = os.getenv("FLOWGATE_OUTPUT_DIR", "").strip()
    if out_dir:
        platform = (data.get("platform") or "video").strip() or "video"
        stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        return Path(out_dir) / f"flowgate_{platform}_{stamp}.md"
    return None


def _print_billing(data: dict) -> None:
    billing = data.get("billing") or {}
    total = billing.get("total_credits")
    if total is None:
        return
    base = billing.get("base_credits", 0)
    token = billing.get("token_credits", 0)
    print(f"\n本次扣费 {total} 积分（保底 {base} + token {token}）· 剩余余额 {data.get('balance')} 积分")


def cmd_transcribe_file(args: argparse.Namespace) -> int:
    base_url = resolve_base_url(args)
    api_key = resolve_api_key(args)
    file_path = Path(args.file)
    if not file_path.exists() or not file_path.is_file():
        raise ApiError(f"找不到文件：{file_path}")

    extra = {"transcribe": "false" if args.no_transcribe else "true"}
    size_mb = file_path.stat().st_size / 1024 / 1024
    print(f"上传本地文件 {file_path.name}（{size_mb:.1f} MB），服务端抽音频 / 分片转写中……")
    _, data = upload_file(base_url, "/v1/transcribe-file", api_key, file_path,
                          timeout=args.timeout, extra_fields=extra)

    if args.json:
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0

    _print_summary(data)
    report = data.get("report_markdown") or ""
    out_path = _resolve_output(args, data)
    if out_path:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(report, encoding="utf-8")
        print(f"\n报告已保存：{out_path}")
    elif report:
        print()
        print(report)
    if data.get("notes"):
        print(f"\n备注：{data['notes']}")
    _print_billing(data)
    return 0


# --------------------------------------------------------------------------- #
# batch: Excel/CSV of links -> knowledge-base zip
# --------------------------------------------------------------------------- #

_BATCH_TERMINAL = {"done", "failed", "canceled", "cancelled"}


def _print_batch_progress(st: dict) -> None:
    total = st.get("total", 0)
    processed = st.get("processed", 0)
    succeeded = st.get("succeeded", 0)
    failed = st.get("failed", 0)
    credits = st.get("credits_charged", 0)
    status = st.get("status", "")
    print(f"  [{status:>8}] {processed}/{total} 已处理 · 成功 {succeeded} · 失败 {failed} · 计费 {credits} 积分")


def cmd_batch(args: argparse.Namespace) -> int:
    base_url = resolve_base_url(args)
    api_key = resolve_api_key(args)
    file_path = Path(args.file)
    if not file_path.exists() or not file_path.is_file():
        raise ApiError(f"找不到文件：{file_path}")

    status_code, data = upload_file(base_url, "/v1/batch", api_key, file_path, timeout=args.timeout)
    batch_no = data.get("batch_no")
    if not batch_no:
        raise ApiError(f"提交失败：{data.get('message') or data}")
    total = data.get("total", "?")
    print(f"已提交批量任务 {batch_no}（共 {total} 行），服务端解析中……")

    if args.no_wait:
        print(f"稍后可用 `batch-status {batch_no}` 查询进度，完成后用 `batch-status {batch_no} --download` 下载。")
        return 0

    st = _poll_batch(base_url, api_key, batch_no, args.poll_interval, args.timeout)
    if st.get("status") != "done":
        raise ApiError(f"批量任务未成功完成（状态：{st.get('status')}）：{st.get('error') or '见任务详情'}")

    out_path = _resolve_batch_output(args, batch_no)
    size = download_file(base_url, f"/v1/batch/{batch_no}/download", api_key, out_path, timeout=args.timeout)
    print(f"\n知识库已下载：{out_path}（{size // 1024} KB）")
    print(f"成功 {st.get('succeeded', 0)} · 失败 {st.get('failed', 0)} · 累计计费 {st.get('credits_charged', 0)} 积分")
    return 0


def _poll_batch(base_url: str, api_key: str, batch_no: str, interval: int, timeout: int) -> dict:
    last = None
    while True:
        _, st = request("GET", base_url, f"/v1/batch/{batch_no}", api_key, timeout=timeout)
        snapshot = (st.get("status"), st.get("processed"), st.get("succeeded"), st.get("failed"))
        if snapshot != last:
            _print_batch_progress(st)
            last = snapshot
        if (st.get("status") or "") in _BATCH_TERMINAL:
            return st
        time.sleep(max(1, interval))


def _resolve_batch_output(args: argparse.Namespace, batch_no: str) -> Path:
    if args.output:
        return Path(args.output)
    out_dir = os.getenv("FLOWGATE_OUTPUT_DIR", "").strip() or "."
    return Path(out_dir) / f"knowledge_base_{batch_no}.zip"


def cmd_batch_list(args: argparse.Namespace) -> int:
    base_url = resolve_base_url(args)
    api_key = resolve_api_key(args)
    _, data = request("GET", base_url, "/v1/batch", api_key, timeout=args.timeout)
    batches = data.get("batches") or []
    if not batches:
        print("暂无批量任务。")
        return 0
    print(f"共 {len(batches)} 个批量任务：")
    for b in batches:
        print(
            f"  {b.get('batch_no')} · {b.get('status'):>8} · "
            f"{b.get('processed', 0)}/{b.get('total', 0)} · 失败 {b.get('failed', 0)} · "
            f"{b.get('filename', '')} · {b.get('created_at', '')}"
        )
    return 0


def cmd_batch_status(args: argparse.Namespace) -> int:
    base_url = resolve_base_url(args)
    api_key = resolve_api_key(args)
    batch_no = (args.batch_no or "").strip()
    if not batch_no:
        raise ApiError("请提供批量任务号（batch_no）。")
    _, st = request("GET", base_url, f"/v1/batch/{batch_no}", api_key, timeout=args.timeout)
    print(f"任务 {batch_no}（{st.get('filename', '')}）：")
    _print_batch_progress(st)
    if args.download:
        if (st.get("status") or "") != "done":
            raise ApiError(f"任务尚未完成（状态：{st.get('status')}），暂不能下载。")
        out_path = _resolve_batch_output(args, batch_no)
        size = download_file(base_url, f"/v1/batch/{batch_no}/download", api_key, out_path, timeout=args.timeout)
        print(f"知识库已下载：{out_path}（{size // 1024} KB）")
    return 0


def cmd_balance(args: argparse.Namespace) -> int:
    base_url = resolve_base_url(args)
    api_key = resolve_api_key(args)
    _, data = request("GET", base_url, "/v1/balance", api_key, timeout=args.timeout)
    print(f"余额：{data.get('balance')} 积分")
    if data.get("invite_code"):
        print(
            f"邀请码：{data['invite_code']}"
            f"（已邀请 {data.get('invite_count', 0)} 人，累计返 {data.get('invite_reward_total', 0)} 积分）"
        )
    return 0


def cmd_usage(args: argparse.Namespace) -> int:
    base_url = resolve_base_url(args)
    api_key = resolve_api_key(args)
    path = "/v1/usage?" + urllib.parse.urlencode({"limit": max(1, args.limit)})
    _, data = request("GET", base_url, path, api_key, timeout=args.timeout)
    logs = data.get("usage") or []
    if not logs:
        print("暂无用量记录。")
        return 0
    print(f"最近 {len(logs)} 条用量：")
    for row in logs:
        when = row.get("created_at") or row.get("time") or ""
        status = row.get("status") or ""
        credits = row.get("credits_charged", 0)
        platform = row.get("platform") or ""
        target = row.get("url") or ""
        print(f"  [{when}] {status:>10} · {credits} 积分 · {platform} · {target}")
    return 0


def cmd_redeem(args: argparse.Namespace) -> int:
    base_url = resolve_base_url(args)
    api_key = resolve_api_key(args)
    code = (args.code or "").strip()
    if not code:
        raise ApiError("请提供卡密。")
    _, data = request("POST", base_url, "/v1/redeem", api_key, body={"code": code}, timeout=args.timeout)
    print(data.get("message") or f"兑换成功，+{data.get('credits_added')} 积分，余额 {data.get('balance')} 积分。")
    return 0


# --------------------------------------------------------------------------- #

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="flowgate",
        description="FlowGate 视频解析 API 客户端（社交视频/图文 → Markdown 报告）。",
    )
    # Shared options attached to each subcommand, so `flowgate <cmd> ... --api-key X`
    # works with the flags placed AFTER the subcommand (the natural position).
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--base-url", default="", help=f"API 前缀（默认 {DEFAULT_BASE_URL}，或 FLOWGATE_BASE_URL）")
    common.add_argument("--api-key", default="", help="API Key（默认取环境变量 FLOWGATE_API_KEY）")
    sub = parser.add_subparsers(dest="command", required=True)

    p_t = sub.add_parser("transcribe", parents=[common], help="解析并转写一个链接")
    p_t.add_argument("url", help="公开的社交视频/图文链接")
    p_t.add_argument("--no-transcribe", action="store_true", help="只取元信息与媒体地址，跳过转写")
    p_t.add_argument("--output", "-o", default="", help="把 Markdown 报告保存到该文件")
    p_t.add_argument("--json", action="store_true", help="打印完整 JSON 响应（机器可读）")
    p_t.add_argument("--timeout", type=int, default=600, help="请求超时秒数（默认 600，长视频可调大）")
    p_t.set_defaults(func=cmd_transcribe)

    p_tf = sub.add_parser("transcribe-file", parents=[common], help="上传本地音视频文件并转写")
    p_tf.add_argument("file", help="本地音频/视频文件路径（大文件服务端自动抽音频+分片）")
    p_tf.add_argument("--no-transcribe", action="store_true", help="只登记文件信息，跳过转写")
    p_tf.add_argument("--output", "-o", default="", help="把 Markdown 报告保存到该文件")
    p_tf.add_argument("--json", action="store_true", help="打印完整 JSON 响应（机器可读）")
    p_tf.add_argument("--timeout", type=int, default=1200, help="请求超时秒数（默认 1200，长视频含抽音频/分片）")
    p_tf.set_defaults(func=cmd_transcribe_file)

    p_bat = sub.add_parser("batch", parents=[common], help="批量解析 Excel/CSV → 知识库 zip")
    p_bat.add_argument("file", help="含「作品链接」列的 .xlsx / .xls / .csv 文件")
    p_bat.add_argument("--output", "-o", default="", help="知识库 zip 保存路径（默认 knowledge_base_<no>.zip）")
    p_bat.add_argument("--no-wait", action="store_true", help="只提交，不轮询等待完成")
    p_bat.add_argument("--poll-interval", type=int, default=5, help="轮询间隔秒数（默认 5）")
    p_bat.add_argument("--timeout", type=int, default=600, help="单次请求超时秒数（默认 600）")
    p_bat.set_defaults(func=cmd_batch)

    p_bl = sub.add_parser("batch-list", parents=[common], help="我的批量任务列表")
    p_bl.add_argument("--timeout", type=int, default=60)
    p_bl.set_defaults(func=cmd_batch_list)

    p_bs = sub.add_parser("batch-status", parents=[common], help="查询批量任务进度")
    p_bs.add_argument("batch_no", help="批量任务号")
    p_bs.add_argument("--download", action="store_true", help="若已完成则顺带下载知识库 zip")
    p_bs.add_argument("--output", "-o", default="", help="下载时的 zip 保存路径")
    p_bs.add_argument("--timeout", type=int, default=300)
    p_bs.set_defaults(func=cmd_batch_status)

    p_b = sub.add_parser("balance", parents=[common], help="查询积分余额")
    p_b.add_argument("--timeout", type=int, default=60)
    p_b.set_defaults(func=cmd_balance)

    p_u = sub.add_parser("usage", parents=[common], help="最近用量流水")
    p_u.add_argument("--limit", type=int, default=20, help="返回条数（默认 20）")
    p_u.add_argument("--timeout", type=int, default=60)
    p_u.set_defaults(func=cmd_usage)

    p_r = sub.add_parser("redeem", parents=[common], help="兑换卡密充值")
    p_r.add_argument("code", help="卡密")
    p_r.add_argument("--timeout", type=int, default=60)
    p_r.set_defaults(func=cmd_redeem)

    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except ApiError as exc:
        eprint(f"错误：{exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
